=== Chat AZZAO ===
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Agrega el asistente de chat de AZZAO al sitio.

== Instalacion ==

1. En el panel de WordPress, vaya a Plugins -> Anadir nuevo -> Subir plugin.
2. Suba el archivo chat-azzao-wordpress.zip y active el plugin.
3. Vaya a Ajustes -> Chat AZZAO.
4. En "Direccion del bot" escriba la direccion https donde corre el servidor
   del chat, por ejemplo https://chat.azzao.com, sin barra al final.
5. Guarde. El chat aparece en el sitio.

== Antes de instalar ==

El servidor del bot debe estar corriendo y accesible por https. Este plugin
solo carga la burbuja y la conecta; no contiene el bot.

En el archivo .env del bot debe estar autorizado el dominio del sitio:

    DOMINIOS_PERMITIDOS=https://azzao.com,https://www.azzao.com

== Preguntas frecuentes ==

= No veo la burbuja en el sitio =

Revise, en este orden: que la casilla "Mostrar el chat en el sitio" este
marcada; que la direccion del bot empiece por https; que el dominio del sitio
este autorizado en el bot; y que el cache del sitio se haya limpiado.

= Se ve en el escritorio pero no en el celular =

Casi siempre es cache. Limpie el cache del plugin de velocidad y el de
Cloudflare si lo usa.

= Como lo apago sin desinstalarlo =

Desmarque "Mostrar el chat en el sitio" en Ajustes -> Chat AZZAO.

== Registro de cambios ==

= 1.0.0 =
* Version inicial.
